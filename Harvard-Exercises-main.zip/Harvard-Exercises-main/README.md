# Harvard-Exercises
Recopilation of the results from different exercises made during the Harvard course

- To run them just modify the main function of each file as needed and run the file directly

  ## Neural Network:
  Basic implementation of Neural networks (with functions)
  
  Applied to following datasets: NLP, computer vision and speech recognition.
  
  File: [NeuralNetworks.py](https://github.com/luiscuervo/Harvard-Exercises/blob/main/NeuralNetworks.py)
  
  ## Convolutional Networks
  Implementation of convolutional Networks
  
  Applied to following datasets: computer vision and speech recognition.
  
  File: [ConvolutionalNetwork.py](https://github.com/luiscuervo/Harvard-Exercises/blob/main/ConvolutionalNetwork.py)
  
  ## GAN:
  Augmentation of datasets using GAN functions
  
  File: [GAN.py](https://github.com/luiscuervo/Harvard-Exercises/blob/main/GAN.py)
  
  ## LSTM:
  Implementation of LSTM functions
  
  (this exercise was adapted to work with cough recordings and has some extra functions)
  
  File: [LSTM.py](https://github.com/luiscuervo/Harvard-Exercises/blob/main/LSTM.py)
